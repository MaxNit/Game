# tictacttoe
Simply import the project into Unity to explore the assets or run the executable in Windows to install and play the game.
